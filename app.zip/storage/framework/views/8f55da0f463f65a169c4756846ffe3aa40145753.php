<div>
    <div class="dropdown cart-dropdown mr-0 mr-lg-2 text-white">
        <div class="cart-overlay"></div>
        <a href="<?php echo e(route('wishlist')); ?>" class="cart-toggle label-down link d-xs-show ls-normal"> 
            <i style="color: black!important" class="w-icon-heart">
                <?php if(Cart::instance('wishlist')->content()->count() > 0): ?>
                <span class="cart-count text-white"><?php echo e(Cart::instance('wishlist')->content()->count()); ?></span>
                <?php endif; ?>
            </i>
            <span style="color: black!important" class="wishlist-label">Wishlist</span>
        </a>
    </div>
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/wishlist-icon-component.blade.php ENDPATH**/ ?>