<form method="get" action="<?php echo e(route('search')); ?>" class="input-wrapper header-search hs-expanded hs-round bg-white br-xs d-md-flex">
    <div class="select-box bg-white">
        <select id="category">
            <option value="0" selected>All Categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e(ucfirst($category->name)); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <input type="text" class="form-control bg-white" name="query" id="search" placeholder="Search in..." value="<?php echo e($query); ?>" required />
    <button class="btn btn-search" type="submit"><i class="w-icon-search"></i></button>
</form>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/search-component.blade.php ENDPATH**/ ?>