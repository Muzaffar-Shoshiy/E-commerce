<?php $__env->startSection('content'); ?>
    <main role="main" class="main-content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="row">
                        <!-- Recent orders -->
                        <div class="col-md-12">
                            <?php if(Session::has('success')): ?>
                            <div class="alert alert-success">
                                <strong class="text-success"><?php echo e(Session::get('success')); ?></strong>
                            </div>
                            <?php endif; ?>
                            <h6 class="mb-3">Last orders</h6>
                            <table class="table table-borderless table-striped">
                                <thead>
                                    <tr role="row">
                                        <th>ID</th>
                                        <th>Category name</th>
                                        <th>Category slug</th>
                                        <th>Parent ID</th>
                                        <th>Image</th>
                                        <th>Created at</th>
                                        <th>Updated at</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="col"><?php echo e($category->id); ?></th>
                                        <td><?php echo e(ucfirst($category->name)); ?></td>
                                        <td><?php echo e($category->slug); ?></td>
                                        <td><?php echo e($category->parent_id); ?></td>
                                        <td><img src="<?php echo e(asset('storage'.'/'.$category->image)); ?>" width="100px" alt="<?php echo e(asset('storage'.'/'.$category->image)); ?>"></td>
                                        <td><?php echo e($category->created_at); ?></td>
                                        <td><?php echo e($category->updated_at); ?></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-sm dropdown-toggle more-vertical"
                                                    type="button" data-toggle="dropdown" aria-haspopup="true"
                                                    aria-expanded="false">
                                                    <span class="text-muted sr-only">Action</span>
                                                </button>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <form action="<?php echo e(route('categories.edit', ['category' => $category->id])); ?>" method="GET">
                                                        <?php echo csrf_field(); ?>
                                                        <button class="dropdown-item" type="submit">Edit</button>
                                                    </form>
                                                    <form action="<?php echo e(route('categories.destroy', ['category' => $category->id])); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button class="dropdown-item"  type="submit">Remove</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo e($categories->links('pagination::bootstrap-5')); ?>

                        </div> <!-- / .col-md-3 -->
                    </div> <!-- end section -->
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/backend/categories.blade.php ENDPATH**/ ?>