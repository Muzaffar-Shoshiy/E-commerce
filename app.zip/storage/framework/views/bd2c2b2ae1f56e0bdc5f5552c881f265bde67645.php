<?php $__env->startSection('content'); ?>
<main role="main" class="main-content">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class="row">
                    <!-- Recent orders -->
                    <div class="col-md-12">
                        <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <strong class="text-success"><?php echo e(Session::get('success')); ?></strong>
                        </div>
                        <?php endif; ?>
                        <h6 class="mb-3">Update Category - <?php echo e(ucfirst($category->name)); ?></h6>
                        <div class="row">
                            <div class="col-md-6">
                                <form action="<?php echo e(route('categories.update', ['category' => $category->id])); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="form-group mb-3">
                                        <label for="name">Name</label>
                                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($category->name); ?>">
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="image">Image</label>
                                        <input type="file" name="image" id="image" class="form-control">
                                    </div>
                                    <div class="form-group mb-3">
                                        <button type="submit" class="btn btn-success">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div> <!-- / .col-md-3 -->
                </div> <!-- end section -->
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/backend/category_edit.blade.php ENDPATH**/ ?>