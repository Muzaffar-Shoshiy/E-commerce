<div class="dropdown category-dropdown">
    <a href="#" class="category-toggle text-white bg-primary text-capitalize" role="button"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"
        data-display="static" title="Browse Categories">
        <i class="w-icon-category"></i>
        <span>Browse  Categories</span>
    </a>

    <div class="dropdown-box text-default">
        <ul class="menu vertical-menu category-menu">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($category->childs->count() > 0): ?>
                <li>
                    <a href="/category/<?php echo e($category->slug); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                    <ul class="megamenu">
                        <?php $__currentLoopData = $category->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <ul>
                                    <li>
                                        <a href="/category/<?php echo e($subcat->slug); ?>">
                                            <?php echo e($subcat->name); ?>

                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <?php else: ?>
                <li>
                    <a href="/category/<?php echo e($category->slug); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/category-component.blade.php ENDPATH**/ ?>