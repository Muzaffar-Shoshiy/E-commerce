<div>
    <!-- Start of Main -->
    <main class="main wishlist-page">
        <!-- Start of Page Header -->
        <div class="page-header">
            <div class="container">
                <h1 class="page-title mb-0">Wishlist</h1>
            </div>
        </div>
        <!-- End of Page Header -->

        <!-- Start of Breadcrumb -->
        <nav class="breadcrumb-nav mb-10">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="/">Home</a></li>
                    <li>Wishlist</li>
                </ul>
            </div>
        </nav>
        <!-- End of Breadcrumb -->

        <!-- Start of PageContent -->
        <div class="page-content">
            <div class="container">
                <?php if(Cart::instance('wishlist')->content()->count() > 0): ?>
                <h3 class="wishlist-title">My wishlist</h3>
                <table class="shop-table wishlist-table">
                    <thead>
                        <tr>
                            <th class="product-price"><span>Product</span></th>
                            <th class="product-price"><span>Nomination</span></th>
                            <th class="product-price"><span>Price</span></th>
                            <th class="wishlist-action">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="product-thumbnail">
                                <div class="p-relative">
                                    <a href="<?php echo e(route('product', ['slug' => $content->model->slug])); ?>">
                                        <figure>
                                            <img src="<?php echo e(asset('storage'.'/'.$content->model->image)); ?>" alt="product" width="200" height="228">
                                        </figure>
                                    </a>
                                    <button wire:click.prevent="removeFromWishlist(<?php echo e($content->model->id); ?>)" type="button" class="btn btn-close"><i class="fas fa-times"></i></button>
                                </div>
                            </td>
                            <td class="product-name">
                                <a href="<?php echo e(route('product', ['slug' => $content->model->slug])); ?>">
                                    <?php echo e($content->name); ?>

                                </a>
                            </td>
                            <td class="product-price">
                                <ins class="new-price">$<?php echo e($content->price); ?></ins>
                            </td>
                            <td class="wishlist-action">
                                <div class="d-lg-flex">
                                    <a wire:click.prevent="store(<?php echo e($content->id); ?>,'<?php echo e($content->name); ?>',<?php echo e($content->price); ?>)" href="#" class="btn btn-dark btn-rounded btn-sm ml-lg-2 btn-cart">Add to cart</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php else: ?>
                <h1 class="text-center">Nothing in Wishlist</h1>
                <div class="text-center mb-5"><a class="btn btn-cart" href="<?php echo e(route('home')); ?>">Start shopping</a></div>
                <?php endif; ?>
            </div>
        </div>
        <!-- End of PageContent -->
    </main>
    <!-- End of Main -->
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/wishlist-component.blade.php ENDPATH**/ ?>