<div>
    <div class="dropdown cart-dropdown cart-offcanvas mr-0 mr-lg-2 text-white">
        <div class="cart-overlay"></div>
        <a href="#" class="cart-toggle label-down link">
            <i style="color: black!important" class="w-icon-cart">
                <?php if(Cart::instance('cart')->content()->count() > 0): ?>
                    <span class="cart-count text-white"><?php echo e(Cart::instance('cart')->content()->count()); ?></span>
                <?php endif; ?>
            </i>
            <span style="color: black!important" class="cart-label">Cart</span>
        </a>
        <div class="dropdown-box">
            <div class="cart-header">
                <span>Shopping Cart</span>
                <a href="#" class="btn-close">Close<i class="w-icon-long-arrow-right"></i></a>
            </div>
            <?php if(Cart::instance('cart')->content()->count() != 0): ?>
            <div class="products">
                <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product product-cart">
                        <div class="product-detail">
                            <a href="<?php echo e(route('product', ['slug' => $product->model->slug])); ?>" class="product-name"><?php echo e($product->name); ?></a>
                                <div class="price-box">
                                    <span class="product-quantity"><?php echo e($product->qty); ?></span>
                                    <span class="product-price">$<?php echo e($product->price); ?></span>
                                </div>
                            </div>
                        <figure class="product-media">
                            <a href="<?php echo e(route('product',['slug' => $product->model->slug])); ?>">
                                <img src="<?php echo e(asset('storage'.'/'.$product->model->image)); ?>" alt="product" height="84" width="94">
                            </a>
                        </figure>
                        <button wire:click.prevent="destroy('<?php echo e($product->rowId); ?>')" class="btn btn-link btn-close" aria-label="Close">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="cart-total" style="margin-top: 300px">
                <label>Subtotal:</label>
                <span class="price">$<?php echo e(Cart::subtotal()); ?></span>
            </div>

            <div class="cart-action">
                <a href="<?php echo e(route('cart')); ?>" class="btn btn-dark btn-outline btn-rounded">View Cart</a>
                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary  btn-rounded">Checkout</a>
            </div>
            <?php else: ?>
            <h6 class="text-center">Nothing in Cart</h6>
            <?php endif; ?>
        </div>
        <!-- End of Dropdown Box -->
    </div>
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/cart-icon-component.blade.php ENDPATH**/ ?>