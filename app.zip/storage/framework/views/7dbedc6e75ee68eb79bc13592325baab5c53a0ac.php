<div>
    <!-- Start of Main -->
    <main class="main cart">
        <!-- Start of Breadcrumb -->
        <nav class="breadcrumb-nav">
            <div class="container">
                <ul class="breadcrumb shop-breadcrumb bb-no">
                    <li class="active"><a href="<?php echo e(route('cart')); ?>">Shopping Cart</a></li>
                    
                    <li><a href="<?php echo e(route('checkout')); ?>">Checkout</a></li>
                    
                    <li><a href="<?php echo e(route('checkout')); ?>">Order Complete</a></li>
                </ul>
            </div>
        </nav>
        <!-- End of Breadcrumb -->

        <!-- Start of PageContent -->
        <div class="page-content">
            <div class="container">
                <div class="row gutter-lg mb-10">
                    <?php if(Cart::instance('cart')->content()->count() > 0): ?>
                    <div class="col-lg-8 pr-lg-4 mb-6">
                        <table class="shop-table cart-table">
                            <thead>
                                <tr>
                                    <th class="product-price"><span>Product</span></th>
                                    <th class="product-price">Nomination</th>
                                    <th class="product-price"><span>Price</span></th>
                                    <th class="product-quantity"><span>Quantity</span></th>
                                    <th class="product-subtotal"><span>Subtotal</span></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="product-thumbnail">
                                        <div class="p-relative">
                                            <a href="<?php echo e(route('product', ['slug' => $products->model->slug])); ?>">
                                                <figure>
                                                    <img src="<?php echo e(asset('storage'.'/'.$products->model->image)); ?>" alt="product" width="200" height="228">
                                                </figure>
                                            </a>
                                            <button wire:click.prevent="destroy('<?php echo e($products->rowId); ?>')" type="button" class="btn btn-close"><i class="fas fa-times"></i></button>
                                        </div>
                                    </td>
                                    <td class="product-name">
                                        <a href="#">
                                            <?php echo e($products->name); ?>

                                        </a>
                                    </td>
                                    <td class="product-price"><span class="amount">$<?php echo e($products->price); ?></span></td>
                                    <td class="product-quantity">
                                        <div class="input-group">
                                            <input class="form-control" style="width: 70px!important" type="number" value="<?php echo e($products->qty); ?>">
                                            <button wire:click.prevent="increaseQuantity('<?php echo e($products->rowId); ?>')" type="button" class="quantity-plus w-icon-plus"></button>
                                            <button wire:click.prevent="decreaseQuantity('<?php echo e($products->rowId); ?>')" type="button" class="quantity-minus w-icon-minus"></button>
                                        </div>
                                    </td>
                                    <td class="product-subtotal">
                                        <span class="amount">$<?php echo e($products->subtotal); ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="cart-action mb-6">
                            <a href="<?php echo e(route('home')); ?>" class="btn btn-dark btn-rounded btn-icon-left btn-shopping mr-auto"><i class="w-icon-long-arrow-left"></i>Continue Shopping</a>
                            <button wire:click.prevent="clearAll()" type="button" class="btn btn-rounded btn-default btn-clear" name="clear_cart" value="Clear Cart">Clear Cart</button>
                        </div>
                    </div>
                    <div class="col-lg-4 sticky-sidebar-wrapper">
                        <div class="sticky-sidebar">
                            <div class="cart-summary mb-4">
                                <h3 class="cart-title text-uppercase">Cart Totals</h3>
                                <div class="cart-subtotal d-flex align-items-center justify-content-between">
                                    <h4>Subtotal</h4>
                                    <span>$<?php echo e(Cart::subtotal()); ?></span>
                                </div>

                                <hr class="divider">

                                <hr class="divider mb-6">
                                <div class="order-total d-flex justify-content-between align-items-center">
                                    <h3>Total</h3>
                                    <span class="ls-50">$<?php echo e(Cart::total()); ?></span>
                                </div>
                                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-block btn-dark btn-icon-right btn-rounded  btn-checkout">Proceed to checkout<i class="w-icon-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <h1 class="text-center">Nothing in Cart</h1>
                    <div class="text-center mb-5"><a class="btn btn-cart" href="<?php echo e(route('shop')); ?>">Start shopping</a></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- End of PageContent -->
    </main>
    <!-- End of Main -->
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/cart-component.blade.php ENDPATH**/ ?>