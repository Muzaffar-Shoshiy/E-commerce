<div>
    <!-- Start of Main -->
    <main class="main">
        <div class="container pb-2">
            <div class="intro-section mb-2">
                <div class="row">
                    <div class="intro-slide-wrapper col-lg-9">
                        <div class="swiper-container swiper-theme animation-slider pg-inner pg-xxl-hide pg-show pg-white nav-xxl-show nav-hide" data-swiper-options = "{
                            'spaceBetween': 0,
                            'slidesPerView': 1
                        }">
                            <div class="swiper-wrapper gutter-no row cols-1">
                                <div class="swiper-slide banner banner-fixed intro-slide intro-slide1 br-sm text-center"
                                    style="background-image: url(assets/images/demos/demo11/slides/slide-1.jpg); background-color: #5B98B7;">
                                    <div class="banner-content y-50">
                                        <h3 class="banner-title text-capitalize text-white font-secondary font-weight-normal ls-0 slide-animate"
                                            data-animation-options="{'name': 'fadeInLeftShorter', 'duration': '.5s', 'delay': '.2s'}">
                                            City Light
                                        </h3>
                                        <h4 class="banner-subtitle text-uppercase text-white font-weight-normal ls-0 slide-animate"
                                            data-animation-options="{'name': 'fadeInRightShorter', 'duration': '.5s', 'delay': '.4s'}">
                                            New Trends This Season
                                        </h4>
                                        <span class="font-weight-bolder text-uppercase text-white slide-animate d-block ls-normal"
                                            data-animation-options="{'name': 'fadeInRightShorter', 'duration': '.5s', 'delay': '.4s'}">
                                            Fashion Show 2021
                                        </span>
                                        <a href="shop-banner-sidebar.html" class="btn btn-white btn-outline btn-rounded btn-icon-right br-xs slide-animate"
                                            data-animation-options="{'name': 'fadeInRightShorter', 'duration': '.5s', 'delay': '.6s'}">
                                            Discover Now<i class="w-icon-long-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                                <!-- End of Intro Slide 1 -->
                                <div class="swiper-slide banner banner-fixed intro-slide intro-slide2 br-sm"
                                    style="background-image: url(assets/images/demos/demo11/slides/slide-2.jpg); background-color: #DFE0E4;">
                                    <div class="banner-content">
                                        <div class="slide-animate" data-animation-options="{
                                            'name': 'fadeInDownShorter', 'duration': '1s'
                                            }">
                                            <h3 class="banner-title text-capitalize text-dark font-secondary font-weight-normal mb-1">New Arrivals!</h3>
                                            <h4 class="banner-price-info text-capitalize text-dark mb-4 ls-25">
                                                Lifestyle From <strong class="text-secondary">$25.99</strong>
                                            </h4>
                                            <a href="shop-banner-sidebar.html" class="btn btn-dark btn-rounded btn-icon-right">
                                                Discover Now
                                                <i class="w-icon-long-arrow-right"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!-- End of Intro Slide 2 -->
                                <div class="swiper-slide banner banner-fixed intro-slide intro-slide3 br-sm" style="background-image: url(assets/images/demos/demo11/slides/slide-3.jpg); background-color: #ECECEC;">
                                    <div class="banner-content y-50">
                                        <div class="slide-animate" data-animation-options="{'name': 'fadeInLeftShorter', 'duration': '1s'}">
                                            <h3 class="banner-title text-capitalize text-dark font-secondary font-weight-normal">From Online Store</h3>
                                            <h4 class="banner-price-info text-dark ls-25">
                                                <strong>Get up to</strong><br>
                                                35% OFF!
                                            </h4>
                                            <div class="d-flex">
                                                <a href="shop-banner-sidebar.html" class="btn btn-dark btn-rounded btn-icon-right mt-4 mr-6">
                                                    Shop Now
                                                    <i class="w-icon-long-arrow-right"></i>
                                                </a>
                                                <img src="assets/images/demos/demo11/sale-sm.png" alt="sale" width="196" height="136">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End of Intro Slide 3 -->
                            </div>
                            <div class="swiper-pagination"></div>
                            <button class="swiper-button-next"></button>
                            <button class="swiper-button-prev"></button>
                        </div>
                    </div>
                    <div class="intro-banner-wrapper col-lg-3 mt-4">
                        <div class="banner banner-fixed intro-banner col-lg-12 col-sm-6 br-sm mb-4">
                            <figure>
                                <img src="assets/images/demos/demo11/banner/banner-1.jpg" alt="Category Banner" width="680" height="180" style="background-color: #E4E7EC;" />
                            </figure>
                            <div class="banner-content">
                                <h4 class="banner-subtitle text-capitalize text-default font-secondary font-weight-normal">Top Products</h4>
                                <h3 class="banner-title text-dark text-uppercase ls-25">Soft Towel</h3>
                                <a href="shop-banner-sidebar.html" class="btn btn-dark btn-link btn-underline btn-icon-right">
                                    Shop Now<i class="w-icon-long-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- End of Intro Banner -->
                        <div class="banner banner-fixed intro-banner col-lg-12 col-sm-6 intro-banner2 mb-4 br-sm">
                            <figure>
                                <img src="assets/images/demos/demo11/banner/banner-2.jpg" alt="Category Banner" width="680" height="180" style="background-color: #33363B;" />
                            </figure>
                            <div class="banner-content">
                                <h4 class="banner-subtitle text-capitalize font-secondary font-weight-normal">New Arrivals</h4>
                                <h3 class="banner-title text-white text-uppercase ls-25">Fresh Cameras</h3>
                                <a href="shop-banner-sidebar.html" class="btn btn-white btn-link btn-underline btn-icon-right">
                                    Shop Now<i class="w-icon-long-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                        <!-- End of Intro Banner -->
                    </div>
                </div>
            </div>
            <!-- End of Intro-section -->

            <div class="swiper-container swiper-theme icon-box-wrapper br-sm bg-white" data-swiper-options="{
                'loop': true,
                'spaceBetween': 10,
                'autoplay': false,
                'autoplayTimeout': 4000,
                'slidesPerView': 1,
                'breakpoints': {
                    '576': {
                        'slidesPerView': 2
                    },
                    '768': {
                        'slidesPerView': 2
                    },
                    '992': {
                        'slidesPerView': 3
                    },
                    '1200': {
                        'slidesPerView': 4
                    }
                }
                }">
                <div class="swiper-wrapper row cols-md-4 cols-sm-3 cols-1">
                    <div class="swiper-slide icon-box icon-box-side text-dark">
                        <span class="icon-box-icon icon-shipping">
                            <i class="w-icon-truck"></i>
                        </span>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title font-weight-bolder">Free Shipping & Returns</h4>
                            <p class="text-default">For all orders over $99</p>
                        </div>
                    </div>
                    <div class="swiper-slide icon-box icon-box-side text-dark">
                        <span class="icon-box-icon icon-payment">
                            <i class="w-icon-bag"></i>
                        </span>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title font-weight-bolder">Secure Payment</h4>
                            <p class="text-default">We ensure secure payment</p>
                        </div>
                    </div>
                    <div class="swiper-slide icon-box icon-box-side text-dark icon-box-money">
                        <span class="icon-box-icon icon-money">
                            <i class="w-icon-money"></i>
                        </span>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title font-weight-bolder">Money Back Guarantee</h4>
                            <p class="text-default">Any back within 30 days</p>
                        </div>
                    </div>
                    <div class="swiper-slide icon-box icon-box-side text-dark icon-box-chat">
                        <span class="icon-box-icon icon-chat">
                            <i class="w-icon-chat"></i>
                        </span>
                        <div class="icon-box-content">
                            <h4 class="icon-box-title font-weight-bolder">Customer Support</h4>
                            <p class="text-default">Call or email us 24/7</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End of Icon Box Wrapper -->

            <div class="swiper-container swiper-theme icon-category-wrapper shadow-swiper appear-animate mb-10 pb-2" data-swiper-options="{'spaceBetween': 20,'slidesPerView': 2,'breakpoints': {'576': {    'slidesPerView': 3},'768': {    'slidesPerView': 4},'992': {    'slidesPerView': 5},'1200': {    'slidesPerView': 8} }}">
                <div class="swiper-wrapper row cols-xl-8 cols-lg-7 cols-md-6 cols-sm-4 cols-xs-3 cols-2">
                    <?php $__currentLoopData = $catpro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide category category-icon">
                            <a href="<?php echo e(route('category', ['slug' => $category->slug])); ?>">
                                
                                    
                                    <img src="<?php echo e(asset('storage'.'/'.$category->image)); ?>" style="border-radius: 50%;width:150px;height:150px!important;" alt="">
                                
                            </a>
                            <div class="category-content">
                                <h4 class="category-name"><a href="<?php echo e(route('category', ['slug' => $category->slug])); ?>"><?php echo e(ucfirst($category->name)); ?></a></h4>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            <!-- End of Icon Category Wrapper -->

            <div class="banner banner-big-sale appear-animate d-flex pl-3 pr-3 br-sm mb-8" style="background-image: url(assets/images/demos/demo11/banner/full.jpg);
                background-color: #383839;">
                <div class="banner-content align-items-center d-flex flex-wrap">
                    <h4 class="banner-price-info text-secondary text-uppercase lh-1">
                        50% Off
                    </h4>
                    <h4 class="banner-subtitle text-uppercase text-white font-weight-bold">Big Sale Up to</h4>
                    <h3 class="banner-title text-uppercase text-white font-weight-bold ml-2 mr-9">In Electronics Store.</h3>
                    <a href="shop-banner-sidebar.html" class="btn btn-dark btn-rounded btn-icon-right">
                        Discover Now
                        <i class="w-icon-long-arrow-right"></i>
                    </a>
                </div>
            </div>
            <!-- End of Banner Big Sale-->
            
            <?php $__currentLoopData = $catpro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="banner-product-wrapper appear-animate row mb-8">
                <div class="col-xl-3 col-md-4 mb-4">
                    <div class="categories bg-white h-100 d-flex flex-column br-xs">
                        <h3 class="banner-title mb-0"><?php echo e(ucfirst($product->name)); ?></h3>
                            <?php if($product->childs->count() > 0): ?>
                                <?php $__currentLoopData = $product->childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <ul class="list-style-none bb-no pl-0">
                                        <li>
                                            <a href="/products/<?php echo e($subcat->slug); ?>"><?php echo e(ucfirst($subcat->name)); ?></a>
                                        </li>
                                    </ul>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <div></div>
                            <?php endif; ?>
                        <a href="<?php echo e(route('category', ['slug' => $product->slug])); ?>" class="btn btn-dark btn-link btn-underline btn-icon-right font-weight-bold text-uppercase">
                            Browse All<i class="w-icon-long-arrow-right"></i></a>
                    </div>
                </div>
                <div class="product-wrapper col-xl-9 col-md-8 mb-4">
                    <div class="bg-grey pb-0 pt-0 swiper-container swiper-theme h-100" data-swiper-options="{
                            'spaceBetween': 20,
                                'slidesPerView': 2,
                                'breakpoints': {
                                    '576': {
                                        'slidesPerView': 3
                                    },
                                    '768': {
                                        'slidesPerView': 2
                                    },
                                    '1200': {
                                        'slidesPerView': 3
                                    },
                                    '1300': {
                                        'slidesPerView': 4
                                    }
                                }
                            }">
                        <div class="swiper-wrapper row cols-xl-4 cols-lg-3">
                            <?php $__currentLoopData = $product->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide product-wrap">
                                    <div class="product text-center">
                                        <figure class="product-media">
                                            <a href="<?php echo e(route('product', ['slug' => $item->slug])); ?>">
                                                <img src="<?php echo e(asset('storage'.'/'.$item->image)); ?>" alt="Product" width="300" height="337">
                                                <img src="<?php echo e(asset('storage'.'/'.$item->image)); ?>" alt="Product" width="300" height="337">
                                            </a>
                                            <div class="product-action-horizontal">
                                                <a href="#" class="btn-product-icon btn-cart w-icon-cart" wire:click.prevent="store(<?php echo e($item->id); ?>,'<?php echo e($item->name); ?>',<?php echo e($item->price); ?>)" title="Add to cart"></a>
                                                <?php if(Cart::instance('wishlist')->content()->pluck('id')->contains($item->id)): ?>
                                                    <a href="#" class="btn-product-icon btn-wishlist w-icon-heart" wire:click.prevent="removeFromWishlist(<?php echo e($item->id); ?>)" title="Remove from Wishlist"></a>
                                                <?php else: ?>
                                                    <a href="#" class="btn-product-icon btn-wishlist w-icon-heart" wire:click.prevent="addToWishlist(<?php echo e($item->id); ?>, '<?php echo e($item->name); ?>', <?php echo e($item->price); ?>)" title="Wishlist"></a>
                                                <?php endif; ?>
                                                <?php if(Cart::instance('compare')->content()->pluck('id')->contains($item->id)): ?>
                                                    <a href="#" class="btn-product-icon btn-compare w-icon-compare" wire:click.prevent="removeItemFromCompare(<?php echo e($item->id); ?>)" title="Remove from Compare"></a>
                                                <?php else: ?>
                                                    <a href="#" class="btn-product-icon btn-compare w-icon-compare" wire:click.prevent="addToCompare(<?php echo e($item->id); ?>, '<?php echo e($item->name); ?>', <?php echo e($item->price); ?>)" title="Compare"></a>
                                                <?php endif; ?>
                                            </div>
                                        </figure>
                                        <div class="product-details">
                                            <h4 class="product-name"><a href="<?php echo e(route('product', ['slug' => $item->slug])); ?>"><?php echo e($item->name); ?></a></h4>
                                            <div class="ratings-container">
                                                <div class="ratings-full">
                                                    <span class="ratings" style="width: 100%;"></span>
                                                    <span class="tooltiptext tooltip-top"></span>
                                                </div>
                                                <a href="product-default.html" class="rating-reviews">(3 Reviews)</a>
                                            </div>
                                            <div class="product-price">
                                                <ins class="new-price">$<?php echo e($item->price); ?></ins>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <!-- End fo Swiper -->
                </div>
            </div>
            <!-- End of Banner Product Wrapper -->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- End of Container -->

    </main>
    <!-- End of Main -->
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/home-component.blade.php ENDPATH**/ ?>