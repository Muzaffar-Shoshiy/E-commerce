<div>
    <!-- Start of Main -->
    <main class="main">
        <!-- Start of Page Header -->
        <div class="page-header">
            <div class="container">
                <h1 class="page-title">Compare</h1>
            </div>
        </div>
        <!-- End of Page Header -->

        <!-- Start of Breadcrumb -->
        <nav class="breadcrumb-nav mb-2">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li>Compare</li>
                </ul>
            </div>
        </nav>
        <!-- End of Breadcrumb -->

        <?php if(Cart::instance('compare')->content()->count() > 0): ?>
            <!-- Start of Page Content -->
        <div class="page-content mb-10 pb-2">
            <div class="container">
                <div class="compare-table">
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-products">
                        <div class="compare-col compare-field">Product</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="compare-col compare-product">
                                <a wire:click.prevent="removeItemFromCompare(<?php echo e($content->model->id); ?>)" href="#" class="btn remove-product"><i class="w-icon-times-solid"></i></a>
                                <div class="product text-center">
                                    <figure class="product-media">
                                        <a href="product-default.html">
                                            <img src="<?php echo e(asset('storage'.'/'.$content->model->image)); ?>" alt="Product" width="228"
                                                height="257" />
                                        </a>
                                        <div class="product-action-vertical">
                                            <a wire:click.prevent="store(<?php echo e($content->id); ?>,'<?php echo e($content->name); ?>',<?php echo e($content->price); ?>)" href="#" class="btn-product-icon btn-cart w-icon-cart"></a>
                                            <a wire:click.prevent="addToWishlist(<?php echo e($content->id); ?>, '<?php echo e($content->name); ?>', <?php echo e($content->price); ?>)" href="#" class="btn-product-icon btn-wishlist w-icon-heart"></a>
                                        </div>
                                    </figure>
                                    <div class="product-details">
                                        <h3 class="product-name"><a href="<?php echo e(route('product', ['slug' => $content->model->slug])); ?>"><?php echo e($content->model->name); ?></a></h3>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Products -->
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-price">
                        <div class="compare-col compare-field">Price</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="compare-col compare-value">
                            <div class="product-price">
                                <span class="new-price">$<?php echo e($content->model->price); ?></span>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Price -->
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-description">
                        <div class="compare-col compare-field">Description</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="compare-col compare-value">
                            <ul class="list-style-none list-type-check">
                                <li>Ultrices eros in cursus turpis massa cursus mattis.</li>
                                <li>Volutpat ac tincidunt vitae semper quis lectus.</li>
                                <li>Aliquam id diam maecenas ultricies mi eget mauris.</li>
                            </ul>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Description -->
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-reviews">
                        <div class="compare-col compare-field">Ratings &amp; Reviews</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="compare-col compare-rating">
                            <div class="ratings-container">
                                <div class="ratings-full">
                                    <span class="ratings" style="width: 80%;"></span>
                                    <span class="tooltiptext tooltip-top"></span>
                                </div>
                                <a href="#" class="rating-reviews">(3 Reviews)</a>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Reviews -->
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-category">
                        <div class="compare-col compare-field">Category</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="compare-col compare-value"><?php echo e(ucfirst($content->model->category->name)); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Category -->
                    <div class="compare-row cols-xl-5 cols-lg-4 cols-md-3 cols-2 compare-meta">
                        <div class="compare-col compare-field">SKU</div>
                        <?php $__currentLoopData = Cart::instance('compare')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="compare-col compare-value">MS46891344</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- End of Compare Meta -->
                </div>
            </div>
            <!-- End of Compare Table -->
        </div>
        <!-- End of Page Content -->
        <?php else: ?>
            <h1 class="text-center">Nothing to Compare</h1>
            <div class="text-center mb-5"><a class="btn btn-cart" href="<?php echo e(route('home')); ?>">Start shopping</a></div>
        <?php endif; ?>
    </main>
    <!-- End of Main -->
</div>
<?php /**PATH D:\OSPanel\domains\laravel\electronics\resources\views/livewire/compare-component.blade.php ENDPATH**/ ?>